extends Node2D
const DB=preload("res://scripts/levels.gd")
const Hero=preload("res://scripts/player.gd")
var player: CharacterBody2D
var index=0
var level: Dictionary
var solids: Array=[]
var items: Array=[]
var coins: Array=[]
var enemies: Array=[]
var spikes: Array=[]
var collected: Array=[]
var effects: Array=[]
var checkpoint=Vector2(110,575)
var checkpoint_on=false
var hp=3
var hits=0
var coin_count=0
var timer=0.0
var active=false
var portal_open=false
var nearest=-1
var lift: AnimatableBody2D
signal changed
signal message(text: String, good: bool)
signal completed
signal sound(kind: String)
func setup(id: int) -> void:
	index=id
	level=DB.LEVELS[id]
	for c in get_children():
		remove_child(c)
		c.queue_free()
	solids=[];items=[];coins=[];enemies=[];spikes=[];collected=[];effects=[]
	hp=3;hits=0;coin_count=0;timer=0;checkpoint_on=false;portal_open=false;nearest=-1
	checkpoint=Vector2(110,575)
	for rect in [Rect2(0,620,680,120),Rect2(790,620,610,120),Rect2(1500,620,400,120),Rect2(2010,620,390,120),Rect2(440,500,200,24),Rect2(700,385,175,24),Rect2(935,535,200,24),Rect2(1185,420,210,24),Rect2(1455,545,220,24),Rect2(1720,435,210,24),Rect2(1990,545,220,24)]:
		platform(rect)
	# A vertical ferry gives a second route across the first chasm.
	lift=AnimatableBody2D.new()
	lift.sync_to_physics=false
	lift.position=Vector2(870,515)
	var shape=CollisionShape2D.new()
	var box=RectangleShape2D.new();box.size=Vector2(100,18);shape.shape=box
	lift.add_child(shape);add_child(lift)
	var points=[Vector2(290,565),Vector2(520,445),Vector2(780,330),Vector2(1040,480),Vector2(1280,365),Vector2(1550,490),Vector2(1810,380),Vector2(2070,490),Vector2(2190,565)]
	var vals=DB.values(id)
	if id==4: points=[Vector2(290,565),Vector2(520,445),Vector2(780,330),Vector2(1280,365),Vector2(1550,490),Vector2(2070,490)]
	for i in range(vals.size()): items.append({"pos":points[i],"value":vals[i],"taken":false,"flash":0.0})
	for pos in [Vector2(190,570),Vector2(375,570),Vector2(460,455),Vector2(610,455),Vector2(720,340),Vector2(850,340),Vector2(970,490),Vector2(1210,375),Vector2(1370,375),Vector2(1600,500),Vector2(1780,390),Vector2(2135,500)]: coins.append({"pos":pos,"taken":false})
	if id>0:
		enemies.append({"x":1080.0,"y":589.0,"origin":1080.0,"radius":100.0,"alive":true,"phase":0.0})
		enemies.append({"x":1650.0,"y":589.0,"origin":1650.0,"radius":100.0,"alive":true,"phase":2.0})
	if id>1: enemies.append({"x":2180.0,"y":589.0,"origin":2180.0,"radius":80.0,"alive":true,"phase":4.0})
	if id>0: spikes=[Rect2(1295,601,65,19),Rect2(1770,601,60,19)]
	player=Hero.new()
	add_child(player)
	player.position=checkpoint
	player.jumped.connect(func(): sound.emit("jump"))
	player.dashed.connect(func(): sound.emit("dash"))
	var camera=Camera2D.new()
	camera.position=Vector2(640,360)
	camera.position_smoothing_enabled=true
	camera.position_smoothing_speed=6
	camera.limit_left=0;camera.limit_right=2400;camera.limit_top=0;camera.limit_bottom=720
	add_child(camera)
	camera.make_current()
	active=true
	changed.emit()
	queue_redraw()
func platform(rect: Rect2) -> void:
	solids.append(rect)
	var body=StaticBody2D.new()
	body.position=rect.get_center()
	var shape=CollisionShape2D.new()
	var box=RectangleShape2D.new();box.size=rect.size;shape.shape=box
	body.add_child(shape);add_child(body)
func _physics_process(dt: float) -> void:
	if not active or not is_instance_valid(player): return
	timer+=dt
	lift.position.y=515+sin(timer*1.2)*42
	var camera=get_viewport().get_camera_2d()
	if camera: camera.position=Vector2(clampf(player.position.x,640,1760),360)
	nearest=-1
	var distance=82.0
	for i in range(items.size()):
		items[i].flash=maxf(0,items[i].flash-dt)
		if items[i].taken: continue
		var d=player.position.distance_to(items[i].pos)
		if d<distance: nearest=i;distance=d
	if Input.is_action_just_pressed("interact"): interact()
	for coin in coins:
		if not coin.taken and player.position.distance_to(coin.pos)<34:
			coin.taken=true;coin_count+=1
			burst(coin.pos,Color("ffda83"));sound.emit("coin");changed.emit()
	for enemy in enemies:
		if not enemy.alive: continue
		enemy.x=enemy.origin+sin(timer*1.3+enemy.phase)*enemy.radius
		if player.position.distance_to(Vector2(enemy.x,enemy.y))<38:
			if player.dash_time>0:
				enemy.alive=false;burst(Vector2(enemy.x,enemy.y),Color("ff829c"));sound.emit("break")
			else: damage("Drone de patrulha! Salte por cima ou use Shift para atravessá-lo com impulso.")
	for rect in spikes:
		if rect.intersects(Rect2(player.position-Vector2(13,21),Vector2(26,44))): damage("Espinhos! Use pulo duplo para passar por cima.")
	if player.position.y>770: damage("Você caiu! Retorno ao checkpoint, sem perder os cristais.",true)
	if not checkpoint_on and player.position.x>980:
		checkpoint_on=true;checkpoint=Vector2(990,590)
		message.emit("Checkpoint ativado. Seus cristais continuam com você ao cair.",true)
		burst(Vector2(990,580),Color("68e0b8"));sound.emit("checkpoint")
	if portal_open and player.position.distance_to(Vector2(2310,568))<58:
		active=false;player.enabled=false;sound.emit("win");completed.emit()
	for i in range(effects.size()-1,-1,-1):
		effects[i].life-=dt
		effects[i].pos+=effects[i].vel*dt
		effects[i].vel.y+=200*dt
		if effects[i].life<=0: effects.remove_at(i)
	queue_redraw()
func interact() -> void:
	if nearest<0:
		if player.position.x>2200 and not portal_open: message.emit("O portal aguarda %d cristal(is) ou cápsula(s). Explore também as plataformas altas." % (DB.target_keys(index).size()-collected.size()),false)
		return
	var item: Dictionary=items[nearest]
	var value=item.value
	var k=DB.key(value)
	if k in collected:
		item.taken=true
		message.emit("%s já pertence à sua coleção. Repetir um elemento não aumenta um conjunto!" % DB.display(value),true)
		sound.emit("coin")
	elif DB.accepts(level,value):
		item.taken=true;collected.append(k)
		burst(item.pos,Color(level.accent));sound.emit("correct")
		var explanation="%s pertence à coleção!" % DB.display(value)
		if index==4: explanation="Cápsula %s aceita: todos os seus elementos pertencem a A." % DB.display(value)
		if index==4 and value.is_empty(): explanation="Cápsula ∅ aceita! O conjunto vazio é subconjunto de qualquer conjunto."
		message.emit(explanation,true)
		portal_open=collected.size()==DB.target_keys(index).size()
		if portal_open: message.emit("Portal carregado! Vá até o arco luminoso no extremo direito da ilha.",true)
		changed.emit()
	else:
		item.flash=0.6;sound.emit("wrong")
		var reason="%s não pertence a A. Deixe este cristal na ilha." % DB.display(value)
		match level.kind:
			"union": reason="%s não pertence nem a A nem a B. Não entra na união." % DB.display(value)
			"intersection": reason="%s não está nos DOIS conjuntos ao mesmo tempo. Não entra na interseção." % DB.display(value)
			"complement": reason="%s está em A: não entra no complemento." % DB.display(value) if value in DB.U else "%s está fora de U: não entra no complemento!" % DB.display(value)
			"subset": reason="A cápsula %s contém elemento fora de A. Ela não é subconjunto de A." % DB.display(value)
		message.emit(reason,false)
func damage(reason: String, force=false) -> void:
	if player.invincible>0 and not force: return
	hits+=1;hp-=1
	if hp<=0: hp=3;reason+=" Traje recarregado: continue tentando!"
	player.reset_at(checkpoint)
	message.emit(reason,false);sound.emit("hurt");changed.emit()
func burst(pos: Vector2,color: Color) -> void:
	for i in range(12): effects.append({"pos":pos,"vel":Vector2.from_angle(TAU*i/12)*randf_range(55,140),"life":0.65,"color":color})
func text(at: Vector2, value: String, size=18, color=Color.WHITE) -> void:
	draw_string(ThemeDB.fallback_font,at,value,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)
func centered(at: Vector2,value: String,size=18,color=Color.WHITE) -> void:
	var width=ThemeDB.fallback_font.get_string_size(value,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
	text(at-Vector2(width/2,0),value,size,color)
func _draw() -> void:
	var accent=Color(level.get("accent","68e0b8"))
	# Panoramic sky and hand-drawn layered island silhouettes.
	draw_rect(Rect2(-1000,-500,4500,1500),Color("0b152c"))
	for i in range(12):
		var y=i*60.0
		draw_rect(Rect2(-500,y,3500,60),Color("0c1831").lerp(Color("244859"),float(i)/15))
	for i in range(75):
		var pos=Vector2(fmod(i*173.1,2600),50+fmod(i*97.7,390))
		draw_circle(pos,1+float(i%3)*0.4,Color(0.7,0.87,1,0.25+sin(timer+i)*0.15))
	draw_circle(Vector2(2040,200),82,Color("c5ddd6"))
	draw_circle(Vector2(2065,180),78,Color("193449"))
	for i in range(9):
		var x=i*340.0-120
		draw_colored_polygon(PackedVector2Array([Vector2(x,600),Vector2(x+100,310+(i%3)*35),Vector2(x+180,350),Vector2(x+230,290),Vector2(x+400,620)]),Color("1b354a"))
	for i in range(16):
		var x=i*180.0
		draw_line(Vector2(x,612),Vector2(x+45,480+(i%4)*20),Color("2b4b58"),7)
		draw_circle(Vector2(x+45,480+(i%4)*20),28,Color("284955"))
	for rect in solids:
		draw_style_box(box(Color("22394c"),8),rect)
		draw_rect(Rect2(rect.position,Vector2(rect.size.x,7)),accent.darkened(0.22))
		for i in range(int(rect.size.x/42)):
			var x=rect.position.x+i*42+16
			draw_line(Vector2(x,rect.position.y+10),Vector2(x+7,rect.position.y+20),Color("35546a"),2)
		if rect.size.y<40:
			draw_colored_polygon(PackedVector2Array([rect.position+Vector2(10,24),rect.position+Vector2(rect.size.x-10,24),rect.position+Vector2(rect.size.x*0.65,68),rect.position+Vector2(rect.size.x*0.28,52)]),Color("1c3046"))
		else:
			for i in range(int(rect.size.x/95)):
				var x=rect.position.x+i*95+38
				draw_line(Vector2(x,rect.position.y),Vector2(x-5,rect.position.y-15),accent.darkened(0.35),2)
				draw_line(Vector2(x,rect.position.y),Vector2(x+9,rect.position.y-10),accent.darkened(0.35),2)
	if is_instance_valid(lift):
		draw_style_box(box(Color("47778a"),6),Rect2(lift.position-Vector2(50,9),Vector2(100,18)))
		centered(lift.position+Vector2(0,5),"↕",18)
	for rect in spikes:
		for i in range(int(rect.size.x/13)):
			var p=rect.position+Vector2(i*13,0)
			draw_colored_polygon(PackedVector2Array([p+Vector2(0,19),p+Vector2(6,0),p+Vector2(13,19)]),Color("f78fa7"))
	# Checkpoint beacon and destination portal.
	draw_line(Vector2(990,620),Vector2(990,570),Color("b6d1de"),4)
	draw_colored_polygon(PackedVector2Array([Vector2(992,570),Vector2(1024,580),Vector2(992,590)]),Color("68e0b8") if checkpoint_on else Color("697f96"))
	var portal_color=accent if portal_open else Color("566581")
	for i in range(3): draw_arc(Vector2(2310,568),42+i*7,PI,TAU,32,Color(portal_color,0.8-float(i)*0.2),4,true)
	draw_line(Vector2(2268,568),Vector2(2268,620),portal_color,5)
	draw_line(Vector2(2352,568),Vector2(2352,620),portal_color,5)
	if portal_open:
		draw_circle(Vector2(2310,578),33+sin(timer*4)*4,Color(accent,0.18))
		centered(Vector2(2310,500),"ENTRE NO PORTAL",16,accent)
	else: centered(Vector2(2310,500),"PORTAL SEM ENERGIA",14,Color("aabbd3"))
	for i in range(items.size()):
		var item: Dictionary=items[i]
		if item.taken: continue
		var p: Vector2=item.pos+Vector2(0,sin(timer*2+i)*4)
		var value=item.value
		var color=Color("ffda83")
		var tag="U"
		if index==4: tag="C";color=accent
		else:
			if value in level.a and value in level.b: tag="AB";color=Color("a5a4ff")
			elif value in level.a: tag="A";color=Color("57daed")
			elif value in level.b: tag="B";color=Color("c49bff")
			elif not value in DB.U: tag="fora de U";color=Color("acb8c9")
		if item.flash>0: color=Color("ff8799")
		draw_circle(p,36,Color(color,0.08))
		if index==4:
			draw_style_box(box(Color("243956"),12),Rect2(p-Vector2(57,22),Vector2(114,44)))
			draw_style_box(outline(color),Rect2(p-Vector2(57,22),Vector2(114,44)))
		else:
			draw_colored_polygon(PackedVector2Array([p+Vector2(0,-27),p+Vector2(23,0),p+Vector2(0,27),p+Vector2(-23,0)]),color.darkened(0.45))
			draw_polyline(PackedVector2Array([p+Vector2(0,-27),p+Vector2(23,0),p+Vector2(0,27),p+Vector2(-23,0),p+Vector2(0,-27)]),color,2,true)
		centered(p+Vector2(0,7),DB.display(value),18 if index==4 else 23,Color.WHITE)
		centered(p+Vector2(0,-35),tag,14,color)
		if i==nearest: centered(p+Vector2(0,51),"[E] RECOLHER",15,Color.WHITE)
	for coin in coins:
		if coin.taken: continue
		var p: Vector2=coin.pos+Vector2(0,sin(timer*3+coin.pos.x)*3)
		draw_circle(p,8,Color("ffcc71"));draw_circle(p,4,Color("a76f43"));draw_line(p-Vector2(0,3),p+Vector2(0,3),Color("fff0b8"),2)
	for enemy in enemies:
		if not enemy.alive: continue
		var p=Vector2(enemy.x,enemy.y)
		draw_line(p-Vector2(26,0),p+Vector2(26,0),Color("aa6885"),3)
		draw_circle(p,17,Color("573c60"));draw_arc(p,17,0,TAU,24,Color("ff829c"),2,true)
		draw_style_box(box(Color("ffc3ce"),3),Rect2(p-Vector2(10,4),Vector2(20,7)))
		draw_circle(p+Vector2(0,19),3+sin(timer*18),Color("ffbc86"))
	for effect in effects: draw_circle(effect.pos,3,Color(effect.color,minf(1,effect.life*2)))
func box(color: Color,radius: int) -> StyleBoxFlat:
	var style=StyleBoxFlat.new();style.bg_color=color;style.set_corner_radius_all(radius);return style
func outline(color: Color) -> StyleBoxFlat:
	var style=box(Color.TRANSPARENT,12);style.set_border_width_all(2);style.border_color=color;return style
