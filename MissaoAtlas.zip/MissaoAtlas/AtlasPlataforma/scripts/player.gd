extends CharacterBody2D
var spawn=Vector2(110,540)
var jumps=2
var coyote=0.0
var buffer=0.0
var facing=1.0
var invincible=0.0
var dash_time=0.0
var dash_cooldown=0.0
var clock=0.0
var enabled=true
signal jumped
signal dashed
func _ready() -> void:
	collision_layer=2
	collision_mask=1
	var shape=CollisionShape2D.new()
	var rect=RectangleShape2D.new()
	rect.size=Vector2(28,46)
	shape.shape=rect
	add_child(shape)
func _physics_process(dt: float) -> void:
	clock+=dt
	invincible=maxf(0,invincible-dt)
	dash_cooldown=maxf(0,dash_cooldown-dt)
	if not enabled:
		queue_redraw()
		return
	var axis=Input.get_axis("left","right")
	if axis!=0: facing=signf(axis)
	if is_on_floor():
		jumps=2
		coyote=0.12
	else: coyote=maxf(0,coyote-dt)
	buffer=maxf(0,buffer-dt)
	if Input.is_action_just_pressed("jump"): buffer=0.14
	if buffer>0 and (jumps>0 or coyote>0):
		# Walking off an edge after coyote time consumes the ground jump.
		if not is_on_floor() and coyote<=0 and jumps==2: jumps=1
		velocity.y=-530
		jumps-=1
		coyote=0
		buffer=0
		jumped.emit()
	if Input.is_action_just_released("jump") and velocity.y < -220: velocity.y=-220
	if Input.is_action_just_pressed("dash") and dash_cooldown<=0:
		dash_time=0.16
		dash_cooldown=0.75
		dashed.emit()
	if dash_time>0:
		dash_time-=dt
		velocity=Vector2(facing*740,0)
	else:
		velocity.x=move_toward(velocity.x,axis*285,2200*dt)
		velocity.y=minf(velocity.y+1450*dt,850)
	move_and_slide()
	position.x=clampf(position.x,22,2370)
	queue_redraw()
func reset_at(point: Vector2) -> void:
	position=point
	velocity=Vector2.ZERO
	jumps=2
	dash_time=0
	invincible=1.5
func _draw() -> void:
	if invincible>0 and int(clock*15)%2==0: return
	var bob=sin(clock*16)*2 if absf(velocity.x)>10 and is_on_floor() else 0.0
	if dash_time>0:
		for i in range(1,5): draw_circle(Vector2(-facing*i*13,0),15-i*2,Color(0.35,0.95,0.9,0.2))
	# Backpack, scarf, boots and helmet: all original vector artwork.
	draw_style_box(box(Color("20466a"),5),Rect2(-19,-7+bob,12,24))
	var tail=PackedVector2Array([Vector2(-facing*8,0+bob),Vector2(-facing*34,7+sin(clock*9)*4),Vector2(-facing*12,10+bob)])
	draw_colored_polygon(tail,Color("ffb56e"))
	draw_style_box(box(Color("e2f4ff"),7),Rect2(-12,-6+bob,24,25))
	var stride=sin(clock*18)*5 if absf(velocity.x)>10 and is_on_floor() else 0.0
	draw_style_box(box(Color("6be8cf"),3),Rect2(-12,15,9,9+stride))
	draw_style_box(box(Color("6be8cf"),3),Rect2(3,15,9,9-stride))
	draw_circle(Vector2(0,-15+bob),17,Color("e2f4ff"))
	draw_style_box(box(Color("163653"),7),Rect2(-12+facing*2,-25+bob,24,17))
	draw_line(Vector2(-6+facing*2,-21+bob),Vector2(5+facing*2,-21+bob),Color("66e6ed"),3)
	draw_circle(Vector2(9*facing,-16+bob),2,Color.WHITE)
	draw_circle(Vector2(0,6+bob),4,Color("203d63"))
func box(color: Color, radius: int) -> StyleBoxFlat:
	var s=StyleBoxFlat.new()
	s.bg_color=color
	s.set_corner_radius_all(radius)
	return s
