extends RefCounted
# Dados separados da física e da interface. Cada coleta exige uma ação no mundo.
const U = [1,2,3,4,5,6,7,8]
const LEVELS = [
	{"title":"O jardim dos elementos", "topic":"Pertinência e definição", "symbol":"x ∈ A", "a":[2,4,6,8], "b":[], "kind":"belongs", "accent":"68e0b8", "story":"Lia pousou nas ilhas flutuantes da Atlas. Recolha os cristais do conjunto A para alimentar o primeiro portal.", "rule":"A = {2, 4, 6, 8}. Um conjunto é uma coleção de elementos bem definidos. Recolha cada elemento de A uma vez.", "hint":"Procure 2, 4, 6 e 8. Ordem e repetições não alteram um conjunto."},
	{"title":"As duas margens", "topic":"União", "symbol":"A ∪ B", "a":[1,2,3], "b":[3,4,5], "kind":"union", "accent":"56d5ef", "story":"Duas colônias alimentam uma ponte de energia. Explore as ilhas e reúna os cristais de A ou B. O 3 aparece duas vezes, mas conta só uma.", "rule":"A = {1, 2, 3}  •  B = {3, 4, 5}. Na união entra quem pertence a A ou B, inclusive aos dois.", "hint":"Reúna {1, 2, 3, 4, 5}. Se encontrar outro 3, não precisa recolhê-lo."},
	{"title":"O eco entre mundos", "topic":"Interseção", "symbol":"A ∩ B", "a":[1,2,4,6], "b":[2,3,4,6,7], "kind":"intersection", "accent":"bb9bff", "story":"O farol precisa de frequências compartilhadas pelas duas colônias. Encontre os cristais que pertencem simultaneamente a A e B.", "rule":"A = {1, 2, 4, 6}  •  B = {2, 3, 4, 6, 7}. A interseção contém somente elementos comuns aos dois conjuntos.", "hint":"Os cristais compartilhados são {2, 4, 6}. A marca AB indica pertencimento aos dois."},
	{"title":"O outro lado da aurora", "topic":"Complemento", "symbol":"U \\ A", "a":[2,4,6,8], "b":[], "kind":"complement", "accent":"ffc578", "story":"Metade dos sensores já foi reparada. Busque somente os cristais que faltam dentro do universo U para acender a aurora.", "rule":"U = {1, 2, 3, 4, 5, 6, 7, 8}  •  A = {2, 4, 6, 8}. O complemento contém os elementos de U que não estão em A.", "hint":"Faltam {1, 3, 5, 7}. Elementos fora de U nunca entram no complemento."},
	{"title":"Cargas para o portal", "topic":"Subconjuntos", "symbol":"C ⊆ A", "a":[1,2,3], "b":[], "kind":"subset", "accent":"ff9fbc", "story":"O portal final transporta cápsulas de suprimentos. Recolha as cápsulas cujos elementos cabem inteiramente em A. Cada cápsula é um conjunto C completo.", "rule":"A = {1, 2, 3}. C ⊆ A quando todo elemento de C pertence a A. ∅ e o próprio A também são subconjuntos de A.", "hint":"Cápsulas válidas: ∅, {1}, {2, 3} e {1, 2, 3}. Uma cápsula com 4 ou 5 não cabe em A."}
]
static func accepts(level: Dictionary, value: Variant) -> bool:
	match level.kind:
		"belongs": return value in level.a
		"union": return value in level.a or value in level.b
		"intersection": return value in level.a and value in level.b
		"complement": return value in U and not value in level.a
		"subset":
			for x in value:
				if not x in level.a: return false
			return true
	return false
static func values(index: int) -> Array:
	if index==4: return [[],[1],[4],[2,3],[2,5],[1,2,3]]
	if index==1: return [1,2,3,6,3,4,5,8]
	if index==3: return [1,2,3,4,5,6,7,8,9]
	return U.duplicate()
static func key(value: Variant) -> String:
	return str(value)
static func target_keys(index: int) -> Array:
	var result: Array=[]
	for value in values(index):
		var k=key(value)
		if accepts(LEVELS[index],value) and not k in result: result.append(k)
	return result
static func display(value: Variant) -> String:
	if value is Array:
		if value.is_empty(): return "∅"
		var parts: PackedStringArray=[]
		for x in value: parts.append(str(x))
		return "{"+", ".join(parts)+"}"
	return str(value)
