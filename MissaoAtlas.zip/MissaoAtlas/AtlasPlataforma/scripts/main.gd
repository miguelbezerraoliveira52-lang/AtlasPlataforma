extends Control
const DB=preload("res://scripts/levels.gd")
const World=preload("res://scripts/world.gd")
var world: Node2D
var ui: CanvasLayer
var hud: Control
var overlay: Control
var goal: Label
var bag: Label
var stats: Label
var toast: Label
var toast_time=0.0
var mode="home"
var current_level=0
var stars: Array=[0,0,0,0,0]
var muted=false
var audio_pool: Array=[]
var audio_slot=0
var save_error=false
func _ready() -> void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	inputs()
	load_save()
	world=World.new();world.process_mode=Node.PROCESS_MODE_PAUSABLE;add_child(world)
	world.changed.connect(update_hud)
	world.message.connect(show_toast)
	world.sound.connect(play_sound)
	world.completed.connect(win)
	ui=CanvasLayer.new();add_child(ui)
	for i in range(8):
		var audio=AudioStreamPlayer.new();audio.volume_db=-10;add_child(audio);audio_pool.append(audio)
	world.setup(0);world.active=false;world.player.enabled=false
	home()
func inputs() -> void:
	var bindings={"left":[KEY_A,KEY_LEFT],"right":[KEY_D,KEY_RIGHT],"jump":[KEY_SPACE,KEY_W,KEY_UP],"interact":[KEY_E],"dash":[KEY_SHIFT],"pause_game":[KEY_ESCAPE],"hint":[KEY_H],"restart_game":[KEY_R],"mute_game":[KEY_M]}
	for action in bindings:
		if not InputMap.has_action(action): InputMap.add_action(action)
		for code in bindings[action]:
			var event=InputEventKey.new();event.physical_keycode=code;InputMap.action_add_event(action,event)
func _process(dt: float) -> void:
	if is_instance_valid(toast) and toast_time>0 and mode=="playing":
		toast_time-=dt
		if toast_time<=0: toast.text=""
	if Input.is_action_just_pressed("mute_game"):
		muted=not muted;save_game()
		if muted:
			for audio in audio_pool: audio.stop()
		if mode=="playing": show_toast("Som desligado" if muted else "Som ligado",true)
	if Input.is_action_just_pressed("pause_game"):
		if mode=="playing": pause_screen()
		elif mode=="paused": resume_game()
	if mode=="playing":
		if Input.is_action_just_pressed("hint"): show_toast(DB.LEVELS[current_level].hint,true,9)
		if Input.is_action_just_pressed("restart_game"): restart_prompt()
func wipe_ui() -> void:
	for c in ui.get_children(): ui.remove_child(c);c.queue_free()
	hud=null;overlay=null;goal=null;bag=null;stats=null;toast=null
func style(color: String, radius=16) -> StyleBoxFlat:
	var s=StyleBoxFlat.new();s.bg_color=Color(color);s.set_corner_radius_all(radius)
	for side in ["left","right","top","bottom"]: s.set("content_margin_"+side,20)
	return s
func text(value: String,size=20,color=Color("e5f3ff")) -> Label:
	var label=Label.new();label.text=value;label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size",size);label.add_theme_color_override("font_color",color)
	return label
func button(value: String,callback: Callable) -> Button:
	var b=Button.new();b.text=value;b.custom_minimum_size.y=48;b.mouse_default_cursor_shape=Control.CURSOR_POINTING_HAND
	b.add_theme_font_size_override("font_size",20)
	for state in ["normal","hover","pressed"]:
		var bs=style("25485c" if state=="normal" else "39778a",10)
		bs.content_margin_top=10;bs.content_margin_bottom=10
		b.add_theme_stylebox_override(state,bs)
	var focus=style("102338",10);focus.bg_color=Color.TRANSPARENT;focus.set_border_width_all(2);focus.border_color=Color("ffcf83")
	b.add_theme_stylebox_override("focus",focus)
	b.pressed.connect(callback)
	return b
func shade() -> Control:
	var layer=Control.new();layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);ui.add_child(layer)
	var dim=ColorRect.new();dim.color=Color(0.025,0.05,0.1,0.88);dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);layer.add_child(dim)
	return layer
func panel(parent: Control,rect: Rect2) -> VBoxContainer:
	var p=PanelContainer.new();p.position=rect.position;p.size=rect.size;p.add_theme_stylebox_override("panel",style("132b40"));parent.add_child(p)
	var v=VBoxContainer.new();v.add_theme_constant_override("separation",14);p.add_child(v);return v
func home() -> void:
	get_tree().paused=false
	mode="home";world.active=false;world.player.enabled=false
	wipe_ui();overlay=shade()
	var left=panel(overlay,Rect2(55,65,480,590))
	left.add_child(text("ATLAS / UMA AVENTURA MATEMÁTICA",16,Color("70e4cf")))
	left.add_child(text("Ilhas dos\nConjuntos",52))
	left.add_child(text("Salte. Explore. Reconstrua.",25,Color("ffcf83")))
	left.add_child(text("Uma tempestade dividiu a Atlas em cinco ilhas. Ajude Lia a reunir energia e abrir o portal de volta para casa.",22))
	left.add_child(text("Conjuntos viram cristais, cápsulas e caminhos. Sem questionário: você aprende explorando o mundo.",20))
	left.add_child(button("Como jogar / controles",help_screen))
	left.add_child(text("A/D mover  •  Espaço pular  •  E recolher\nShift impulso  •  Esc pausa  •  M som",17,Color("a5c4d7")))
	var right=panel(overlay,Rect2(560,65,665,590))
	right.add_child(text("ESCOLHA SUA ILHA",18,Color("70e4cf")))
	for i in range(5):
		var b=button("%02d  %s     %s" % [i+1,DB.LEVELS[i].title,"★".repeat(int(stars[i]))+"☆".repeat(3-int(stars[i]))],intro.bind(i))
		b.alignment=HORIZONTAL_ALIGNMENT_LEFT
		b.add_theme_font_size_override("font_size",18)
		right.add_child(b)
	right.add_child(text("Cada ilha tem uma missão diferente. Todas ficam abertas para explorar e praticar.",18,Color("adc7d6")))
	right.add_child(button("Som: "+("desligado" if muted else "ligado"),toggle_sound_menu))
	right.add_child(button("Apagar estrelas salvas",reset_prompt))
	if save_error: right.add_child(text("Não foi possível salvar neste dispositivo.",15,Color("ffb3aa")))
func toggle_sound_menu() -> void:
	muted=not muted;save_game();home()
func help_screen() -> void:
	wipe_ui();overlay=shade()
	var v=panel(overlay,Rect2(100,35,1080,650))
	v.add_theme_constant_override("separation",12)
	v.add_child(text("Manual da exploradora",34,Color("70e4cf")))
	v.add_child(text("A/D ou ←/→: mover  •  Espaço/W/↑: pular duas vezes  •  Shift: impulso\nE: recolher cristal/cápsula próxima  •  H: dica  •  Esc: pausa  •  R: reiniciar  •  M: som",19))
	v.add_child(text("1. Leia a missão da ilha. Chegue perto de um cristal e pressione E. A marca A, B ou AB informa a qual conjunto ele pertence; o número é o elemento.",19))
	v.add_child(text("2. Colete apenas os elementos pedidos pela operação. Um erro mostra por que o item não entra na coleção, sem tirar vida. Cristais repetidos contam uma vez.",19))
	v.add_child(text("3. Explore plataformas altas com pulo duplo. Moedas douradas são bônus. Desvie de espinhos e drones; o impulso destrói drones, mas não protege dos espinhos.",19))
	v.add_child(text("4. A bandeira central é um checkpoint. Cair ou ser atingido leva você de volta, preservando a coleção. O traje recarrega quando as três cargas acabam; não há game over.",19))
	v.add_child(text("5. Reúna a coleção e entre no portal à direita. Uma estrela por concluir; outra por coletar 6 moedas; outra por sofrer no máximo 2 impactos/quedas. Não há cronômetro.",19))
	v.add_child(text("6. Na última ilha, cada cápsula é um conjunto inteiro, inclusive ∅. O progresso é salvo ao concluir a ilha. Sair ou reiniciar descarta a tentativa atual.",19))
	v.add_child(button("Voltar ao mapa",home))
func intro(id: int) -> void:
	current_level=id;world.setup(id);world.active=false;world.player.enabled=false
	mode="intro";wipe_ui();overlay=shade()
	var level: Dictionary=DB.LEVELS[id]
	var v=panel(overlay,Rect2(150,95,980,530))
	v.add_child(text("ILHA %02d / %s" % [id+1,level.topic],18,Color(level.accent)))
	v.add_child(text(level.title,36))
	v.add_child(text(level.story,23))
	v.add_child(text(level.rule,22,Color("ffcf83")))
	v.add_child(text("Objetivo: recolher %d %s válidos e entrar no portal à direita." % [DB.target_keys(id).size(),"conjuntos-cápsula" if id==4 else "elementos distintos"],22))
	v.add_child(text("Pulo duplo: aperte Espaço novamente no ar. Use E perto dos itens. Se precisar de ajuda, H mostra uma dica.",19,Color("abc9da")))
	v.add_child(button("Explorar ilha  →",begin))
	v.add_child(button("Voltar ao mapa",home))
func begin() -> void:
	get_tree().paused=false;mode="playing";wipe_ui();build_hud()
	world.active=true;world.player.enabled=true
	show_toast("A/D para andar • Espaço duas vezes para pulo duplo • E para recolher",true,7)
func build_hud() -> void:
	hud=Control.new();hud.mouse_filter=Control.MOUSE_FILTER_IGNORE;ui.add_child(hud)
	var banner=PanelContainer.new();banner.position=Vector2(20,16);banner.size=Vector2(1240,128);var bs=style("10283d",14)
	bs.content_margin_top=10;bs.content_margin_bottom=10
	banner.add_theme_stylebox_override("panel",bs);hud.add_child(banner)
	var column=VBoxContainer.new();column.add_theme_constant_override("separation",6);banner.add_child(column)
	var row=HBoxContainer.new();column.add_child(row)
	var title=text("%02d  %s" % [current_level+1,DB.LEVELS[current_level].title],25,Color(DB.LEVELS[current_level].accent));title.size_flags_horizontal=Control.SIZE_EXPAND_FILL;row.add_child(title)
	stats=text("",19);stats.custom_minimum_size.x=340;row.add_child(stats)
	var pause=button("Ⅱ",pause_screen);pause.custom_minimum_size=Vector2(45,35);row.add_child(pause)
	goal=text("",20);column.add_child(goal)
	column.add_child(text(DB.LEVELS[current_level].rule,17,Color("b4ccdb")))
	toast=text("",20);toast.position=Vector2(30,156);toast.size=Vector2(1220,70);hud.add_child(toast)
	var lower=PanelContainer.new();lower.position=Vector2(20,645);lower.size=Vector2(1240,58);lower.add_theme_stylebox_override("panel",style("10283d",12));hud.add_child(lower)
	bag=text("",18);lower.add_child(bag)
	update_hud()
func update_hud() -> void:
	if not is_instance_valid(goal): return
	goal.text="%s   •   Energia do portal: %d / %d   %s" % [DB.LEVELS[current_level].symbol,world.collected.size(),DB.target_keys(current_level).size(),"→ Portal aberto!" if world.portal_open else ""]
	stats.text="Traje %s   •   Moedas %d/12" % ["●".repeat(world.hp)+"○".repeat(3-world.hp),world.coin_count]
	var names: PackedStringArray=[]
	for item in world.items:
		if DB.key(item.value) in world.collected and not DB.display(item.value) in names: names.append(DB.display(item.value))
	bag.text=("Cápsulas: " if current_level==4 else "Coleção: ")+(", ".join(names) if not names.is_empty() else "nenhum item ainda")+"     |     E recolher • Shift impulso • H dica • Esc pausa"
func show_toast(value: String, good: bool, duration=5.0) -> void:
	if not is_instance_valid(toast): return
	toast.text=("✓ " if good else "! ")+value
	toast.add_theme_color_override("font_color",Color("8df0cc") if good else Color("ffb6ac"));toast_time=duration
func pause_screen() -> void:
	if mode!="playing": return
	mode="paused";get_tree().paused=true;overlay=shade()
	var v=panel(overlay,Rect2(240,100,800,520))
	v.add_child(text("Pausa na expedição",35))
	v.add_child(text(DB.LEVELS[current_level].rule,22,Color("ffcf83")))
	v.add_child(text("A/D mover • Espaço pulo duplo • E recolher\nShift impulso • H dica • M som • R reiniciar",21))
	v.add_child(button("Continuar",resume_game))
	v.add_child(button("Reiniciar esta ilha",restart_prompt))
	v.add_child(button("Voltar ao mapa (abandona a tentativa)",home))
func resume_game() -> void:
	if is_instance_valid(overlay): overlay.queue_free();overlay=null
	mode="playing";get_tree().paused=false
func restart_prompt() -> void:
	var previous_mode=mode
	var was_paused=mode=="paused"
	mode="confirm"
	get_tree().paused=true
	var dialog=ConfirmationDialog.new();dialog.title="Reiniciar ilha?";dialog.dialog_text="A coleção e as moedas desta tentativa serão zeradas. Suas estrelas salvas permanecem."
	dialog.process_mode=Node.PROCESS_MODE_ALWAYS
	dialog.confirmed.connect(func(): dialog.queue_free();get_tree().paused=false;intro(current_level))
	dialog.canceled.connect(func(): dialog.queue_free();get_tree().paused=was_paused;mode=previous_mode)
	ui.add_child(dialog);dialog.popup_centered(Vector2i(540,150))
func win() -> void:
	mode="result"
	var earned=1+(1 if world.coin_count>=6 else 0)+(1 if world.hits<=2 else 0)
	stars[current_level]=maxi(int(stars[current_level]),earned);save_game()
	wipe_ui();overlay=shade()
	var v=panel(overlay,Rect2(160,80,960,560))
	v.add_child(text("ILHA RESTAURADA  /  "+"★".repeat(earned)+"☆".repeat(3-earned),26,Color("ffcf83")))
	var complete=true
	for star in stars:
		if int(star)==0: complete=false
	v.add_child(text("A Atlas voltou a brilhar!" if complete else "Portal estabilizado!",38,Color("70e4cf")))
	v.add_child(text("Lia reuniu a energia das cinco ilhas e abriu o caminho de volta para casa. Você pode explorar novamente em busca das três estrelas." if complete else "Lia recuperou mais uma parte da Atlas. Os elementos da sua coleção alimentaram o portal.",23))
	v.add_child(text("%d moedas  •  %d impactos/quedas  •  %d itens matemáticos recuperados" % [world.coin_count,world.hits,world.collected.size()],21))
	v.add_child(text("Aprendizado: "+DB.LEVELS[current_level].rule,21,Color("b6d4e5")))
	v.add_child(text("Estrelas: concluir a ilha + coletar 6 moedas + sofrer no máximo 2 impactos/quedas.",18))
	if save_error: v.add_child(text("Falha ao salvar. O resultado vale apenas nesta sessão.",18,Color("ffb6ac")))
	if current_level<4: v.add_child(button("Próxima ilha →",intro.bind(current_level+1)))
	v.add_child(button("Explorar novamente",intro.bind(current_level)))
	v.add_child(button("Voltar ao mapa",home))
func play_sound(kind: String) -> void:
	if muted: return
	var audio: AudioStreamPlayer=audio_pool[audio_slot%audio_pool.size()];audio_slot+=1
	audio.stream=load("res://assets/"+kind+".wav");audio.play()
func save_game() -> void:
	var cfg=ConfigFile.new();cfg.set_value("game","stars",stars);cfg.set_value("game","muted",muted)
	save_error=cfg.save("user://atlas_platform.cfg")!=OK
func load_save() -> void:
	var cfg=ConfigFile.new()
	if cfg.load("user://atlas_platform.cfg")!=OK: return
	var saved=cfg.get_value("game","stars",[])
	if saved is Array and saved.size()==5:
		for i in range(5):
			if saved[i] is int or saved[i] is float: stars[i]=clampi(int(saved[i]),0,3)
	muted=bool(cfg.get_value("game","muted",false))
func reset_prompt() -> void:
	var dialog=ConfirmationDialog.new();dialog.title="Apagar estrelas?";dialog.dialog_text="As estrelas das cinco ilhas serão apagadas deste dispositivo."
	dialog.confirmed.connect(func(): stars=[0,0,0,0,0];save_game();dialog.queue_free();home())
	dialog.canceled.connect(dialog.queue_free);ui.add_child(dialog);dialog.popup_centered()
