# Atlas: Ilhas dos Conjuntos

**Uma aventura de plataforma 2D no Godot 4.4.1, em português.**

Este projeto substitui a abordagem de quiz por exploração, saltos, coleta e desafios no cenário. Não existem telas de perguntas ou alternativas. O jogador controla Lia e usa conceitos de conjuntos para recuperar a energia de cinco ilhas.

## Começar

### Jogar no Windows

Extraia o ZIP Windows e abra **AtlasConjuntos.exe**. Não é necessário instalar Godot. Versão para Windows 10/11 de 64 bits, com recursos embutidos no executável. O arquivo foi exportado pelo Godot, mas não executado em um sistema Windows neste ambiente. Não possui assinatura digital.

### Abrir o projeto

1. Instale **Godot 4.4.1 Standard**, sem necessidade de .NET.
2. Extraia o ZIP do projeto.
3. No gerenciador do Godot, clique em **Importar** e selecione `AtlasPlataforma/project.godot`.
4. Abra o projeto, aguarde a importação dos sons e pressione **F5**.

A interface, o cenário e os personagens são construídos por GDScript. Portanto, a árvore da cena principal é pequena; os objetos aparecem ao executar o jogo. Godot 3 não é compatível.

### Jogar no navegador

O ZIP Web contém a exportação pronta para um servidor HTTP/HTTPS. Não abra `index.html` por duplo clique. Com Python instalado, entre na pasta Web e execute:

```sh
python -m http.server 8000
```

Abra `http://localhost:8000` em um navegador com WebGL 2. A versão é voltada a computador com teclado; não possui controles de toque. Para disponibilizar publicamente, hospede todos os arquivos juntos em um serviço estático que sirva WebAssembly. O arquivo de entrada é `index.html`. Esta entrega não inclui publicação em um endereço público.

## Enredo

Uma tempestade fragmentou a estação Atlas em ilhas flutuantes. Lia precisa restaurar cinco portais reunindo cristais e cápsulas de suprimentos. Cada ilha trabalha um conceito matemático. Ao restaurar as cinco, a história conclui com a abertura do caminho de volta para casa.

## Controles

| Ação | Teclas |
|---|---|
| Andar | A/D ou setas esquerda/direita |
| Pular | Espaço, W ou seta para cima |
| Pulo duplo | Pressione a tecla de pulo novamente no ar |
| Impulso horizontal | Shift |
| Recolher item próximo | E |
| Dica da missão | H |
| Pausar/continuar | Esc |
| Reiniciar ilha, com confirmação | R |
| Ligar/desligar áudio | M |

Soltar a tecla de pulo cedo reduz sua altura. Para saltos altos, mantenha a tecla pressionada e pressione novamente no ar. O impulso tem recarga de 0,75 segundo. Ele destrói drones durante sua execução, mas não protege de espinhos.

## O que o jogador faz

- Percorre um cenário lateral com plataformas altas, abismos, uma plataforma móvel e moedas bônus.
- Aproxima-se de cristais ou cápsulas e usa E para recolher.
- Decide pela operação da missão quais itens pertencem à coleção.
- Itens inválidos permanecem na ilha e explicam o motivo. Erros matemáticos não causam dano.
- Acompanha a energia do portal e a coleção no painel.
- Ao completar a coleção, atravessa o portal luminoso no extremo direito.

As marcas **A**, **B**, **AB** e **U** acompanham as cores dos cristais. A resolução não exige distinguir cores. O número no cristal é seu elemento; as marcas indicam pertencimento. Moedas douradas não são elementos matemáticos: são recompensas de exploração.

## As cinco missões

| Ilha | Conceito | Objetivo correto |
|---|---|---|
| O jardim dos elementos | Definição e pertinência | Reunir os elementos de A = {2, 4, 6, 8} |
| As duas margens | União | Para A = {1, 2, 3} e B = {3, 4, 5}, reunir {1, 2, 3, 4, 5} |
| O eco entre mundos | Interseção | Para A = {1, 2, 4, 6} e B = {2, 3, 4, 6, 7}, reunir {2, 4, 6} |
| O outro lado da aurora | Complemento | Em U = {1, 2, 3, 4, 5, 6, 7, 8}, retirar A = {2, 4, 6, 8}; reunir {1, 3, 5, 7} |
| Cargas para o portal | Subconjuntos | Para A = {1, 2, 3}, recolher as cápsulas ∅, {1}, {2, 3} e {1, 2, 3} |

Na união existem dois cristais com valor 3 para ensinar que repetição não aumenta um conjunto. Ambos representam o mesmo elemento; qualquer um satisfaz a coleta desse valor.

No complemento existe um cristal 9, explicitamente marcado **fora de U**. Não pertencer a A não é suficiente: o elemento precisa pertencer ao universo.

Na última ilha cada cápsula representa um conjunto inteiro. Recolher uma cápsula ∅ é uma ação válida, distinta de não recolher cápsula alguma. A e ∅ são subconjuntos de A. As cápsulas {4} e {2, 5} são inválidas.

Ao completar as cinco missões, o jogador realiza **20 coletas matemáticas distintas**, além de moedas, saltos e outras interações. As ilhas compartilham a estrutura de plataformas validada; paleta, missão, objetos e presença de perigos variam. A primeira ilha não tem drones nem espinhos para ensinar os controles.

## Vida, checkpoints e estrelas

- O traje possui três cargas. Dano ou queda leva Lia ao último checkpoint.
- A bandeira central ativa o checkpoint automaticamente ao avançar pelo cenário.
- A coleção e as moedas permanecem após dano e queda.
- Ao esgotar as três cargas, o traje recarrega. Não existe tela de game over.
- Cada ilha concluída dá uma estrela; coletar pelo menos seis moedas dá outra; sofrer no máximo dois impactos/quedas dá outra.
- Não há cronômetro nem pontuação por rapidez.
- Todas as ilhas estão disponíveis no mapa, permitindo prática livre.
- Melhores estrelas e preferência de áudio são salvas em `user://atlas_platform.cfg`.
- Coleções e moedas da tentativa atual não são salvas ao fechar o jogo ou voltar ao mapa.
- Reiniciar e apagar estrelas exigem confirmação.

## Arquitetura

| Arquivo | Responsabilidade |
|---|---|
| `main.tscn` | Cena inicial |
| `scripts/main.gd` | Menus, HUD, tutorial, pausa, resultados, áudio e salvamento |
| `scripts/player.gd` | Física, movimentação, pulo duplo, impulso e desenho de Lia |
| `scripts/world.gd` | Plataformas, câmera, itens, moedas, perigos, checkpoint e portal |
| `scripts/levels.gd` | Dados das cinco missões e regras matemáticas |
| `assets/*.wav` | Efeitos sonoros originais |
| `tests/game_test.gd` | Testes de regras e integração |
| `tests/traversal.gd` | Percurso por dez pontos com movimento e colisões reais |
| `tests/capture.gd` | Renderização de telas para revisão visual |
| `previews/` | Capturas do jogo |

As formas do cenário e do personagem são desenhadas por código, sem bibliotecas externas. As colisões usam `CharacterBody2D`, `StaticBody2D` e `AnimatableBody2D`. Os portais só concluem a missão quando a coleção contém todos os elementos válidos distintos.

## Verificação

Validado no Godot 4.4.1 em Linux: **150 verificações de integração sem falhas** e **10 pontos do percurso físico alcançados**.

- Regras de pertinência, união, interseção, complemento e subconjuntos.
- Repetição, vazio, conjunto como subconjunto de si mesmo e elemento fora do universo.
- Coleta válida/inválida, preservação da coleção, checkpoint, portal e estrelas.
- Entrada real de movimento, pulo duplo, impulso e coleta por proximidade.
- Colisão com drones e espinhos, destruição de drones com impulso e queda.
- Pausa, retomada e persistência.
- Percurso físico por dez pontos, incluindo todas as plataformas superiores e o portal, sem falhas de alcance.
- Revisão visual de mapa, manual, introdução, jogo, cápsulas e resultado.
- Exportação para Windows e Web. Não houve execução do binário em Windows nem teste da exportação em navegador neste ambiente.

Executar:

```sh
godot --headless --path . --script res://tests/game_test.gd
godot --headless --path . --script res://tests/traversal.gd
```

Os testes de integração escrevem estrelas no perfil local. Depois de executá-los, use Apagar estrelas salvas no mapa. Não inclua a pasta `.godot` ao distribuir o projeto.

## Exportar novamente

Instale os modelos de exportação da versão 4.4.1 no editor. Em Projeto → Exportar, selecione Windows Desktop ou Web e um destino. Os presets distribuídos utilizam os templates padrão, sem dependências dos caminhos do ambiente de criação. O preset Web não utiliza threads.

## Relação com o trabalho AV2/AV3

O jogo atende ao tema Conjuntos, usa uma narrativa, possui tutorial, dicas internas, feedback visual/sonoro e mais de cinco interações com o conteúdo. Como não é um quiz, a exigência específica de banco de dez questões não se aplica a esta mecânica.

A equipe ainda deve preparar os slides, disponibilizar o executável ou a versão web em um link público, testar o acesso em outra máquina e realizar os testes de usabilidade da AV3 com participantes reais. Resultados de testes com alunos não foram inventados nem incluídos.

Sugestão de teste: peça a colegas para iniciar a primeira ilha sem ajuda; observe se aprendem o pulo duplo, compreendem E, identificam a coleção correta e encontram o portal. Registre dúvidas sobre controles e conceitos separadamente e use os resultados na revisão da AV3.

## Recursos e autoria

Código, desenho vetorial e efeitos de áudio produzidos para esta entrega. O projeto utiliza fonte e componentes padrão do Godot. Identifique a equipe e descreva sua participação e a assistência por IA conforme as regras da disciplina.
