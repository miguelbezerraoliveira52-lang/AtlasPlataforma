extends SceneTree
var game
func _initialize() -> void: call_deferred("run")
func snap(name: String) -> void:
	for i in range(4): await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://../platform_output/"+name+".png")
func run() -> void:
	game=load("res://main.tscn").instantiate();root.add_child(game)
	game.stars=[0,0,0,0,0];game.home()
	await snap("01_mapa")
	game.help_screen();await snap("02_manual")
	game.intro(1);await snap("03_intro")
	game.begin();await snap("04_inicio")
	game.world.player.position=Vector2(1250,390)
	game.world.player.enabled=false
	for i in range(35): await process_frame
	await snap("05_plataforma")
	game.intro(4);game.begin();game.world.player.position=Vector2(1260,390);game.world.player.enabled=false
	for i in range(35): await process_frame
	await snap("06_capsulas")
	for i in range(game.world.items.size()):
		game.world.nearest=i;game.world.interact()
	game.world.player.position=Vector2(2310,568)
	for i in range(4): await physics_frame
	await snap("07_resultado")
	quit()
