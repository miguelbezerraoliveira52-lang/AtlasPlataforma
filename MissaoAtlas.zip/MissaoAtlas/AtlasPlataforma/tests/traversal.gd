extends SceneTree
var game
var failures=0
func _initialize() -> void: call_deferred("run")
func hop(target: Vector2, jump: bool) -> void:
	var hero=game.world.player
	var jumped_twice=false
	Input.action_release("jump")
	await physics_frame
	if jump: Input.action_press("jump")
	var arrived=false
	for frame in range(150):
		var dx=target.x-hero.position.x
		Input.action_release("left");Input.action_release("right")
		if absf(dx)>8: Input.action_press("right" if dx>0 else "left")
		if jump and frame==18: Input.action_release("jump")
		if jump and frame==20: Input.action_press("jump");jumped_twice=true
		if hero.is_on_floor() and absf(hero.position.x-target.x)<16 and absf(hero.position.y-target.y)<7:
			arrived=true;break
		await physics_frame
	Input.action_release("jump");Input.action_release("right");Input.action_release("left")
	if not arrived:
		failures+=1;print("UNREACHED ",target," position ",hero.position)
	else: print("REACHED ",target)
	for i in range(4): await physics_frame
func run() -> void:
	game=load("res://main.tscn").instantiate();root.add_child(game)
	game.muted=true;game.intro(0);game.begin()
	for i in range(20): await physics_frame
	await hop(Vector2(360,597),false)
	await hop(Vector2(520,477),true)
	await hop(Vector2(600,477),false)
	await hop(Vector2(780,362),true)
	await hop(Vector2(1040,512),true)
	await hop(Vector2(1280,397),true)
	await hop(Vector2(1550,522),true)
	await hop(Vector2(1810,412),true)
	await hop(Vector2(2070,522),true)
	await hop(Vector2(2310,597),true)
	print("TRAVERSAL FAILURES: ",failures)
	quit(1 if failures else 0)
