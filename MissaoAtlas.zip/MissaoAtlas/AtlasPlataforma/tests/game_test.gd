extends SceneTree
const DB=preload("res://scripts/levels.gd")
var checks=0
var failures=0
var game
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok: failures+=1;push_error(label)
func _initialize() -> void: call_deferred("run")
func run() -> void:
	game=load("res://main.tscn").instantiate();root.add_child(game)
	await process_frame
	game.muted=true
	game.stars=[0,0,0,0,0]
	check(DB.target_keys(0).size()==4,"Pertinência: 4")
	check(DB.target_keys(1).size()==5,"União com repetição: 5")
	check(DB.target_keys(2).size()==3,"Interseção: 3")
	check(DB.target_keys(3).size()==4,"Complemento: 4")
	check(DB.target_keys(4).size()==4,"Subconjuntos: 4")
	check(DB.accepts(DB.LEVELS[4],[]),"Vazio é subconjunto")
	check(DB.accepts(DB.LEVELS[4],[1,2,3]),"A é subconjunto de A")
	check(not DB.accepts(DB.LEVELS[3],9),"Complemento exclui o exterior de U")
	game.help_screen();await process_frame
	for id in range(5):
		game.intro(id);game.begin()
		await physics_frame
		var world=game.world
		check(not world.portal_open,"Portal inicia fechado")
		for i in range(world.items.size()):
			world.nearest=i
			var count=world.collected.size()
			var value=world.items[i].value
			var was_duplicate=DB.key(value) in world.collected
			world.interact()
			if DB.accepts(DB.LEVELS[id],value):
				check(world.items[i].taken,"Item válido recolhido")
				check(world.collected.size()==count+(0 if was_duplicate else 1),"Conjunto não repete elementos")
			else:
				check(not world.items[i].taken,"Inválido fica no mundo")
				check(world.collected.size()==count,"Inválido não altera coleção")
		check(world.portal_open,"Portal abre com coleção correta")
		check(world.collected.size()==DB.target_keys(id).size(),"Coleção completa")
		var count=world.collected.size()
		world.damage("Teste",true)
		check(world.collected.size()==count,"Dano preserva coleção")
		check(world.hp==2 and world.hits==1,"Dano e contagem")
		world.damage("Teste",true);world.damage("Teste",true)
		check(world.hp==3,"Traje recarrega")
		world.player.position=Vector2(1100,570)
		await physics_frame
		await physics_frame
		check(world.checkpoint_on,"Checkpoint ativa")
		world.damage("Teste",true)
		check(world.player.position.distance_to(world.checkpoint)<5,"Retorno ao checkpoint")
		world.player.position=Vector2(2310,568)
		await physics_frame;await physics_frame;await process_frame
		check(game.mode=="result","Portal termina fase")
		check(game.stars[id]>=1,"Estrela salva")
	game.intro(0);game.begin()
	await physics_frame
	var hero=game.world.player
	for i in range(20): await physics_frame
	var start=hero.position
	Input.action_press("right")
	for i in range(15): await physics_frame
	Input.action_release("right")
	check(hero.position.x>start.x+30,"Movimento real")
	Input.action_press("jump");await physics_frame;await physics_frame
	Input.action_release("jump")
	check(hero.velocity.y<0,"Pulo real")
	for i in range(8): await physics_frame
	Input.action_press("jump");await physics_frame;await physics_frame
	Input.action_release("jump")
	check(hero.jumps==0,"Segundo pulo")
	Input.action_press("dash");await physics_frame;await physics_frame;Input.action_release("dash")
	check(hero.dash_time>0 and absf(hero.velocity.x)>700,"Impulso real")
	game.pause_screen();await process_frame
	check(paused and game.mode=="paused","Pausa")
	game.resume_game();await process_frame
	check(not paused and game.mode=="playing","Retomada")
	game.intro(1);game.begin()
	var w=game.world
	w.player.position=Vector2(2310,568)
	await physics_frame;await physics_frame
	check(game.mode=="playing","Portal fechado não conclui")
	w.player.position=w.items[0].pos
	Input.action_press("interact");await physics_frame;await physics_frame;Input.action_release("interact")
	check(w.collected.size()==1,"Tecla E coleta por proximidade")
	w.player.invincible=0
	w.player.position=Vector2(w.enemies[0].x,w.enemies[0].y)
	await physics_frame;await physics_frame
	check(w.hits==1,"Colisão real com drone")
	w.player.position=Vector2(w.enemies[0].x,w.enemies[0].y)
	w.player.dash_time=0.16
	await physics_frame;await physics_frame
	check(not w.enemies[0].alive,"Impulso destrói drone")
	w.player.invincible=0;w.player.dash_time=0
	w.player.position=w.spikes[0].get_center()-Vector2(0,15)
	await physics_frame;await physics_frame
	check(w.hits==2,"Colisão real com espinhos")
	w.player.position=Vector2(740,800)
	await physics_frame;await physics_frame
	check(w.hits==3 and w.hp==3,"Queda e recarga automática")
	check(w.collected.size()==1,"Danos preservam item recolhido por E")
	game.save_game();game.stars=[0,0,0,0,0];game.load_save()
	check(game.stars==[1,1,1,1,1],"Persistência de estrelas")
	print("CHECKS: ",checks,"; FAILURES: ",failures)
	quit(1 if failures>0 else 0)
